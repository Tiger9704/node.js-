const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const ObjectId = mongoose.ObjectId;

const storySchema = new Schema({
    createdAt: Number,
    updatedAt: Number,
    description: {
        type: String,
        required: [true, 'description field is required'],
        unique: true,
    },
    user: {
        type: ObjectId,
        ref: 'user',
        required: true
    }

}, {timestamps: {currentTime: () => new Date().getTime()    }   })


module.exports = mongoose.model('user', storySchema, 'users;')
