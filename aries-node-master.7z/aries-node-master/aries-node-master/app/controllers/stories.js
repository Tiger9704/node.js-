'use strict'
const Stories = require('../models/stories');

module.exports.getStories = getStories;
module.exports.createStory = createStory;

function createStory(req, res, next) {
    const story = new Stories(req.body);

    story.save(function(err, result)    {
    if(err) {
        return next(err);
    }

    console.log('result', result)
    return res.json({ data: result });
    })
}

function getStories(req, res, next) {
    Stories
    .find()
    .populate('user', 'name email')
    .exec(function(err, result) {
        if(err) {
            return next(err);
        }
        
        res.json({ data: result });
    })
}
