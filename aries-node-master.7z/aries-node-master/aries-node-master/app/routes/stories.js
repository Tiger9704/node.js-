'use strict'

const express = require('express');
const router = express.Router;
const storiesCtrl = require('../controllers/stories');

router.length('/stories', storiesCtrl.getStories);
router.post('/stories', storiesCtrl.createStory);

module.exports = router;