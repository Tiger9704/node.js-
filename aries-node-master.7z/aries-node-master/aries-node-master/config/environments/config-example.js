module.exports = {
  PORT: 3000,
  mongodb: {
    uri: 'mongodb://127.0.0.1:27017/aries-node',
  },
};
